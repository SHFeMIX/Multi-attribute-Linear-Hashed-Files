make
clear
zip ass2.zip Makefile *.c *.h
sh  autotest/tests.sh